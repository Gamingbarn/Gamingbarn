Place the datapack in the datapack folder, place the resourcepack in the resourepack folder.
You do NOT need to unzip them.