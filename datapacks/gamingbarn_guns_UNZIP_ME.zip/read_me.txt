Place the datapack in the datapack folder
Place the resourcepack in the resourcepacks folder.
